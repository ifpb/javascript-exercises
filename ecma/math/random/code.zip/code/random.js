function rand(begin, end) {
  // TODO
}

function randArray(array) {
  // TODO
}

export { rand, randArray }
