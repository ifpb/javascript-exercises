
String.prototype.toCamelCase = function() {
  // TODO
}

String.prototype.toSnakeCase = function() {
  // TODO
}

String.prototype.applyBold = function(text) {
  // TODO
}

export { String }
