
function cpf(){
  // TODO
}

function cnpj(){
  // TODO
}

function cep(){
  // TODO
}

function octal(){
  // TODO
}

export { cpf, cnpj, cep, octal }
