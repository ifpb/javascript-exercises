function citation(name) {
  // TODO
}

function compactCitation(name) {
  // TODO
}

export { citation, compactCitation }
