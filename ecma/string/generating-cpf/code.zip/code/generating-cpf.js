
function cpfCheckDigit(cpf) {
  // TODO
}

export { cpfCheckDigit }
