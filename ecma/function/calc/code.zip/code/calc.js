/**
 * operator: '+', '-', '*', '/'
 */
function calc(operand1, operand2, operator){
  // TODO
}

export {calc}
