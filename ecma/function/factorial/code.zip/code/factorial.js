function factorial(number) {
  // TODO
}

export { factorial };
