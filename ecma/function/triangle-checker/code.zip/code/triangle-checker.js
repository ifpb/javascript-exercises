
function triangleChecker(a, b, c){
  // TODO
}

export { triangleChecker }
