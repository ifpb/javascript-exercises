import { sum } from './sum.mjs';

// Number Tools

// adding 1 + 2
console.log(sum(1, 2));
console.log(3);

// adding 3 + 2
console.log(sum(3, 2));
console.log(5);
