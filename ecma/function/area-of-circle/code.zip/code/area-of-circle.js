
function areaOfCircle(radius) {
  // TODO A = πr²
}

export { areaOfCircle }
