
function fibonacci(number){
  // TODO
}

export { fibonacci }
