import { nthPrime } from './prime-nth.mjs'

// Number Tools

// looking for the first 4 prime number
console.log(nthPrime(4))
console.log(7)

// looking for the first 6 prime number
console.log(nthPrime(6))
console.log(13)
