import { isPrime } from '../../prime/code/prime.js';

/**
 * begin: 1..n
 * end: 1..n, end > begin
 */
function nthPrime(nth) {
  // TODO
}

export { nthPrime };
