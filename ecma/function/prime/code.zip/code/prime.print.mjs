import { isPrime } from './prime.mjs';

// Number Tools

// checking if the number 2 is prime
console.log(isPrime(2));
console.log(true);

// checking if the number 3 is prime
console.log(isPrime(3));
console.log(true);

// checking if the number 4 is prime
console.log(isPrime(4));
console.log(false);

// checking if the number 5 is prime
console.log(isPrime(5));
console.log(true);

// checking if the number 6 is prime
console.log(isPrime(6));
console.log(false);

// checking if the number 7 is prime
console.log(isPrime(7));
console.log(true);
