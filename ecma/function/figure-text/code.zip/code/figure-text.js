
function halfSquare(size){
  // TODO
}

function triangleText(size) {
  // TODO
}

function halfDiamondText(size) {
  // TODO
}

function diamondText(size) {
  // TODO
}

function boardText(size) {
  // TODO
}

export { triangleText, halfDiamondText, diamondText, boardText }
