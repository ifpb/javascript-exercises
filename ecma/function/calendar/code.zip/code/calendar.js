
/** calendar
 * beginWeek: 0..6 - 0(DOM), 1(SEG), 2(TER), 3(QUA), 4(QUI), 5(SEX), 6(SAB)
 * endDay: 28..31
 */
function calendar(beginWeek, endDay) {
  // TODO
}

export { calendar }
