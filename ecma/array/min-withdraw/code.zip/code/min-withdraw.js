
function withdraw(number) {
  // TODO
}

export { withdraw }
