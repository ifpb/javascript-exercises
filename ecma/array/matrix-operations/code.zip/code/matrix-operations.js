
function addingMatrix(a, b) {
  // TODO
}

function multiplyingMatrix(a, b) {
  // TODO
}

export {
  addingMatrix,
  multiplyingMatrix
}
