const size = 10;

// TODO h(10)

// Output:
//  h(10): 2.9289682539682538
