name = 'Alice';

// TODO
// Output:
//  hello Alice
