// BMI = weight/height²

const weight = 60;
const height = 1.65;
let result;

// TODO if

// Output:
//  BMI: 22.03856749311295
//  Result: Normal weight
