class Order {
  // TODO

}

export { Order }
