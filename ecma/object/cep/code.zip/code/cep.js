
function getInfo(cep) {
  // TODO
}

export { getInfo }
