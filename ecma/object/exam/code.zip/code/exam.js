
function grade(student, weight, answer) {
  // TODO
}

function avg(students) {
  // TODO
}

function min(students, count=1) {
  // TODO
}

function max(students, count=1) {
  // TODO
}

function lt(students, limit) {
  // TODO
}

function gt(students, limit) {
  // TODO
}

export { grade, avg, min, max, gt, lt }