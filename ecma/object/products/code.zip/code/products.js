
function total(products) {
  // TODO
}

export { total }
