
class Product {
  // TODO
}

export { Product }
