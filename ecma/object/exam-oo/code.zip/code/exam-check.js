
class ExamCheck {
  // TODO
}

export { ExamCheck }