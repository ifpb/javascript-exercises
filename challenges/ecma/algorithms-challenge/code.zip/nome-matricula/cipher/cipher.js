module.exports = class Cipher {

}
