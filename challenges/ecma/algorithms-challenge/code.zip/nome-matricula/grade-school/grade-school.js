module.exports = class School {

}
