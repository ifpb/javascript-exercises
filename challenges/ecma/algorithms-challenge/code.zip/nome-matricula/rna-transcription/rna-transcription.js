module.exports = class DnaTranscriber {

}
