const md5 = require('./md5')
const Array = require('./array-combination')

class RainbowTable {
  // TODO
  // use: md5(password), Array.letters().combination(length)
}

module.exports RainbowTable