import { sockMerchant } from './sockMerchant.mjs'

console.log(sockMerchant([10, 20, 20, 10, 10, 30, 50, 10, 20])) 
console.log(3)

console.log(sockMerchant([1, 2, 1, 2, 1, 3, 2]))
console.log(2)
