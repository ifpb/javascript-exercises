
function rotLeft(a, d) {
  // TODO
}

function stats(arr) {
  // TODO
}

function miniMaxSum(arr) {
  // TODO
}

function highestFrequency(types) {
  // TODO
}

export {
  rotLeft,
  stats,
  miniMaxSum,
  highestFrequency
}