function repeatedString(s, n) {
  // TODO
}

function mirrorSequence(a, b) {
  // TODO
}

function zeroMeansZero(a, b) {
  // TODO
}

function numberOfLeds(number) {
  // TODO
}

export {
  repeatedString,
  mirrorSequence,
  zeroMeansZero,
  numberOfLeds
}