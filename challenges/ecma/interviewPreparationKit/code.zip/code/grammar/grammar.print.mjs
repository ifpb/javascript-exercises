import { spelling } from './grammar.mjs'

console.log(spelling('programador'))
console.log('P-R-O-G-R-A-M-A-D-O-R')

console.log(spelling('o dia está chuvoso'))
console.log('O-D-I-A-E-S-T-Á-C-H-U-V-O-S-O')
