
function spelling(word) {
  // TODO
}

export { spelling }