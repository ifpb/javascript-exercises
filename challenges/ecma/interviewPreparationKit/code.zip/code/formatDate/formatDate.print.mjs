import { longFormat } from './formatDate.mjs'

console.log(longFormat("22/04/1983"))
console.log("22 de abril de 1983")