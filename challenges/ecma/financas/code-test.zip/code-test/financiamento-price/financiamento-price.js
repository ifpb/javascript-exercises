function financiamentoPrice(financiamento, juroMensal, meses) {
  // TODO
}

export { financiamentoPrice }