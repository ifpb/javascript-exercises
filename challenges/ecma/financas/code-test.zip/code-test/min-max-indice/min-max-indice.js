
function minMaxIndice(tabela, mesInicial, mesFinal) {
  // TODO
}

export { minMaxIndice }
