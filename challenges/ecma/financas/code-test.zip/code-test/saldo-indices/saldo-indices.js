
function saldoIndices(tabela1, tabela2, mesInicial, mesFinal) {
  // TODO
}

export { saldoIndices }
