
function redimentoCompostoVariado(tabela, valorInicial, aporte, mesInicial, mesFinal) {
  // TODO
}

export { redimentoCompostoVariado }
