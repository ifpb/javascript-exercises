
function redimentoCompostoFixo(valorInicial, aporte, juroMensal, meses) {
  // TODO
}

export { redimentoCompostoFixo }