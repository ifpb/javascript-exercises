function financiamentoPrice(financiamento, juroMensal, meses) {
  // TODO
}

console.log(financiamentoPrice(20000, 1.82, 36)) //=> 27437.565620289548
console.log(financiamentoPrice(20000, 1.82, 24)) //=> 24863.60444684676
console.log(financiamentoPrice(20000, 1.82, 12)) //=> 22444.174290541192