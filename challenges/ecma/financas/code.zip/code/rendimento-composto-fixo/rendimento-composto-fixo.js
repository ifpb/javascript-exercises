
function redimentoCompostoFixo(valorInicial, aporte, juroMensal, meses) {
  // TODO
}

console.log(redimentoCompostoFixo(100, 500, 0.5936, 12)) //=> 6307.176654943719
console.log(redimentoCompostoFixo(100, 500, 0.5936, 24)) //=> 12971.227695545636
console.log(redimentoCompostoFixo(100, 500, 0.5936, 36)) //=> 20125.781003832304
console.log(redimentoCompostoFixo(100, 500, 0.5936, 120)) //=> 87335.08961181375