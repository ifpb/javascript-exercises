
class DnaTranscriber {
  // TODO
}

export { DnaTranscriber }
