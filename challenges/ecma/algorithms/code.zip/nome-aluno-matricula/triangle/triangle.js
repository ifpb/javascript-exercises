
class Triangle {
  // TODO
}

export { Triangle }