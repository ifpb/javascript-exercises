
class Cipher {
  // TODO
}

export { Cipher }
