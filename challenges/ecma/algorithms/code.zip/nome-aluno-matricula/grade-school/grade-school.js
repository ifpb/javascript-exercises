
class School {
  // TODO
}

export { School }
