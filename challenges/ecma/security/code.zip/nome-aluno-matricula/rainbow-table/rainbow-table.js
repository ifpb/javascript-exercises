import { md5 } from './md5.js'
import { Array } from './array-combination.js'

class RainbowTable {
  // TODO
  // use: md5(password), Array.letters().combination(length)
}

export { RainbowTable }