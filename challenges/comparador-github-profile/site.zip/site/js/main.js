// https://api.github.com/repos/:owner/:repo
// https://api.github.com/repos/:owner/:repo/languages
// https://api.github.com/repos/:owner/:repo/contributors
// https://api.github.com/repos/:owner/:repo/commits